# nginxLoadBalancerPythonFlask

This is a simple example of login micro services

To get this working on an Ubuntu desktop system

1. Install docker
2. Install docker-compose
3. docker-compose up
 
