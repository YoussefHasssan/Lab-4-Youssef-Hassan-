
if __name__=="__main__":
    print("Main")
else:
    print("Not main")
